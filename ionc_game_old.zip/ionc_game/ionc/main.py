import json, pathlib
from ionc.card import Card
from ionc.player import Player
from ionc.story import StoryRunner
from ionc.ui_cli import CLI
from ionc.savecode import encode, decode

PROJECT = pathlib.Path(__file__).resolve().parent.parent
ASSETS  = PROJECT / "assets"

def load(name: str):
    return json.load(open(ASSETS / name, encoding="utf-8"))
def build_player(codes):
    cards_db={c['id']:c for c in load('cards.json')}
    deck=[]
    flags=load('config.json')['basic_flags'].copy()
    for code in codes:
        try:
            data=decode(code)
            flags.update(data['flags'])
            for cid in data['inherit_cards']:
                if cid in cards_db:
                    deck.append(Card(cards_db[cid]))
        except Exception as e:
            print('存檔碼無效:',e)
    deck += [Card(cards_db[c]) for c in load('config.json')['initial_deck']]
    return Player(deck,flags)
def pick_inherit(player,ui):
    unique={c.id:c for c in player.draw_pile+player.hand+player.discard}
    deck=list(unique.values())
    ui.msg("選擇一張繼承卡:")
    for i,c in enumerate(deck):
        ui.msg(f" {i}. {c}")
    while 1:
        try:
            idx=int(input('> '))
            if idx < 0 or idx >= len(deck):
                ui.msg("無效索引，請重試。")
                continue
            break
        except:
            idx=0
    # idx=max(0,min(idx,len(deck)-1))
    return deck[idx].id
def main():
    ui=CLI()
    ui.msg("輸入存檔碼(最多3行，空行結束)")
    codes=[]
    while len(codes)<3:
        line=input()
        if not line.strip(): break
        codes.append(line.strip())
    player=build_player(codes)
    StoryRunner(ASSETS,player,ui).start()
    inherit=pick_inherit(player,ui)
    payload={'flags':player.flags,'inherit_cards':[inherit]}
    code=encode(payload)
    ui.msg("=== 你的存檔碼 ===")
    ui.msg(code)
if __name__=='__main__':
    main()
