
import json, base64, hashlib, os
VERSION='IONC3'
KEY=b'ionc_secret_key'
def _xor(data,key):
    return bytes(b^key[i%len(key)] for i,b in enumerate(data))
def encode(payload):
    raw=json.dumps(payload).encode()
    enc=_xor(raw,KEY)
    b64=base64.urlsafe_b64encode(enc).decode()
    chk=hashlib.sha256(raw).hexdigest()[:8]
    return f"{VERSION}-{b64}-{chk}"
def decode(token):
    ver,b64,chk=token.split('-')
    if ver!=VERSION: raise ValueError('ver')
    enc=base64.urlsafe_b64decode(b64.encode())
    raw=_xor(enc,KEY)
    if hashlib.sha256(raw).hexdigest()[:8]!=chk:
        raise ValueError('checksum')
    return json.loads(raw)
